/*
 * Decompiled with CFR 0.152.
 */
package ac.grim.grimac.checks.impl.combat;

import ac.grim.grimac.checks.Check;
import ac.grim.grimac.checks.CheckData;
import ac.grim.grimac.player.GrimPlayer;

@CheckData(name="Hitboxes", setback=10.0)
public class Hitboxes
extends Check {
    public Hitboxes(GrimPlayer player) {
        super(player);
    }
}

